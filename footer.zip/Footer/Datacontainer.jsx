// import React from 'react';

// const Datacontainer = ({ id, img, message, info }) => {
//   return (
//     <div className='mx-auto  '>
//       <img src={img} alt={message} className='w-12 h-12 ml-32  rounded-full bg-white' />
//       <h1 className='font-bold pt-3 text-xl text-center'>{message}</h1>
//       <p className='text-center w-80 pt-2 '>{info}</p>
//     </div>
//   );
// };

// export default Datacontainer;


import React from 'react';

const Datacontainer = ({ id, img, message, info }) => {
  return (
    <>
     
    <div className=" p-4 max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg">
      <img 
        src={img} 
        alt={message} 
         className="w-12 h-12 sm:w-16 sm:h-16 md:w-24 md:h-24 lg:w-14 lg:h-14 mx-auto rounded-full bg-white"
      />
      <h1 className="font-bold pt-3 text-lg sm:text-xl lg:text-2xl text-center">
        {message}
      </h1>
      <p className="text-center w-full sm:w-96 lg:w-full pt-2">
        {info}
      </p>
    </div>
    </>
  );
};

export default Datacontainer;
