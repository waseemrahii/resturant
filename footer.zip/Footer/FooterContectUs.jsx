import React from 'react';
import Datacontainer from './Datacontainer';
import { data } from './Data';

const FooterContectUs = () => {
  return (
    <div className='flex flex-col md:flex-row  gap-4 md:gap-[12%] ml-12 justify-center  items-center p-5 md:items-start text-center md:text-left '>
      {data.map((item) => (
        <Datacontainer key={item.id} {...item} />
      ))}
    </div>
  );
};

export default FooterContectUs;
