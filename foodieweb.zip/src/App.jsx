import React from 'react';
// import Restaurants from './components/Restaurants';
// import Header from './components/Header';
import Home from './_root/Pages/HomePage';

const App = () => (
  <div className="App">
    <Home/>
  </div>
);

export default App;