import React from 'react'
import CartComponent from './CartComponent'

const Cart = () => {
  return (
    <div>
     <CartComponent/> 
    </div>
  )
}

export default Cart
