import React from 'react'
import Order from './Order'

const MyOrder = () => {
  return (
    <div>
      <Order/>
    </div>
  )
}

export default MyOrder
