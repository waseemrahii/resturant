import React from 'react'
import MyGift from '../../components/Gifts/MyGift'

const MyGiftCard = () => {
  return (
    <div className='w-[80%] mx-auto'>
      
      <MyGift/>
    </div>
  )
}

export default MyGiftCard
