import React from 'react'
import Address from '../../components/Address/Address'

const DeliveryAddress = () => {
  return (
    <div className='w-[80%] mx-auto'>
        <Address/>    
    </div>
  )
}

export default DeliveryAddress

