import React from 'react'

const MyOrder = () => {
  return (
    <div>
      
      <h1>My Order</h1>
    </div>
  )
}

export default MyOrder
