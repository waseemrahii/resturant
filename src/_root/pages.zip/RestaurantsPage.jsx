import React from 'react'

const RestaurantsPage = () => {
  return (
    <div>
      
    </div>
  )
}

export default RestaurantsPage
