import React from 'react'

const Offers = () => {
  return (
    <div>
      <h1>Offers</h1>      
    </div>
  )
}

export default Offers
