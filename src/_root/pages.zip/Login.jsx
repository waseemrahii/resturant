import React from 'react'

const Login = () => {
  return (
    <div>
      
      <h1>login</h1>
    </div>
  )
}

export default Login
