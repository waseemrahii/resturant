import React from 'react'

const MyGift = () => {
  return (
    <div>
      
      <h1>MyGift</h1>
    </div>
  )
}

export default MyGift
