import React from 'react'

const SignUp = () => {
  return (
    <div>
      <h1>Sign Up</h1>
    </div>
  )
}

export default SignUp
