import React from 'react'

const Checkout = () => {
  return (
    <div>
      <h1>Checkout</h1>
    </div>
  )
}

export default Checkout
