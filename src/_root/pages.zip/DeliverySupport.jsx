import React from 'react'

const DeliverySupport = () => {
  return (
    <div>
      
      <h1>Delivery Support</h1>
    </div>
  )
}

export default DeliverySupport
