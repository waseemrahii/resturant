import React from 'react'

const FavoriteStore = () => {
  return (
    <div>
      <h1>FavoriteStore</h1>
      
    </div>
  )
}

export default FavoriteStore
