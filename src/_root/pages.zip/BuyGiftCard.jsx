import React from 'react'

const BuyGiftCard = () => {
  return (
    <div>
      <h1>Buy Gift Card</h1>
    </div>
  )
}

export default BuyGiftCard
