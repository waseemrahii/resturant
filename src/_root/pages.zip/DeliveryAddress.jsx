import React from 'react'

const DeliveryAddress = () => {
  return (
    <div>
      <h1>Delivery Address</h1>      
    </div>
  )
}

export default DeliveryAddress

