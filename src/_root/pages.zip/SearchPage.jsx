import React from 'react'

const SearchPage = () => {
  return (
    <div>
      <h1>Search Page</h1>
    </div>
  )
}

export default SearchPage
