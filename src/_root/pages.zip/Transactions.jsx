import React from 'react'

const Transactions = () => {
  return (
    <div>
      <h1>Transactions</h1>
    </div>
  )
}

export default Transactions
