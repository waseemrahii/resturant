import React from 'react'
import Faqs from '../../components/Faqs'

const DeliverySupport = () => {
  return (
    <div className='w-[80%] mx-auto'>
      <Faqs/>
    </div>
  )
}

export default DeliverySupport
