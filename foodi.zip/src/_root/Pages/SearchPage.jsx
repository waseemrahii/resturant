import React from 'react'
import Search from '../../components/Search'

const SearchPage = () => {
  return (
    <div className='w-[80%] mx-auto'>
      <Search/>
    </div>
  )
}

export default SearchPage
