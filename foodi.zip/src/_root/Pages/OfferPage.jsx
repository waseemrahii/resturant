import React from 'react'
import Offers from '../../components/Offers'

const OfferPage = () => {
  return (
    <div className='w-[80%] mx-auto'>
      <Offers/>   
    </div>
  )
}

export default OfferPage
