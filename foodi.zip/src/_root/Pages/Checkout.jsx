import React from 'react'
import Cart from '../../components/Cart'

const Checkout = () => {
  return (
    <div className='w-[80%] mx-auto'>
      <Cart/>
    </div>
  )
}

export default Checkout
