import React from 'react'

const Categories = () => {
  return (
    <div className='w-[80%] mx-auto'>
      <h1>Categories</h1>
    </div>
  )
}

export default Categories
