import React from 'react'
import Contact from '../../components/Contact'

const ContactUs = () => {
  return (
    <div className='w-[80%] mx-auto'>
      <Contact/>
    </div>
  )
}

export default ContactUs
