import React from 'react'
import BuyGift from '../../components/Gifts/BuyGift'

const BuyGiftCard = () => {
  return (
    <div className='w-[80%] mx-auto'>
      <BuyGift/>
    </div>
  )
}

export default BuyGiftCard
