import Transacation from './Transactions'

const MyTransactions = () => {
  return (
    <div>
      <Transacation payment='400'/>
    </div>
  )
}

export default MyTransactions
